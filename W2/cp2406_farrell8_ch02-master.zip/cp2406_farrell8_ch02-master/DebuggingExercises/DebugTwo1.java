public class DebugTwo1
{
   public static void main(String[] args)
   {
      int oneInt = 315.0;
      double oneDouble = 12.4;
      char oneChar = A;
      System.out.print("The int is ");
      System.out.pintln(oneInt);
      System.out.print("The double is ");
      System.println(oneDouble);
      System.out.print(The char is ");
      System.out.println(oneChar);
   }
}